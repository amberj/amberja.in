#Assume text is a variable that
#holds a string. Write Python code
#that prints out the position
#of the first occurrence of 'hoo'
#in the value of text, or -1 if
#it does not occur at all.

text = "first hoo" 

#DO NOT USE IMPORT

#ENTER CODE BELOW HERE
#ANY CODE ABOVE WILL CAUSE
#HOMEWORK TO BE GRADED
#INCORRECT

pos = text.find("hoo")
print pos










