#Given the variables s and t defined as:
s = 'udacity'
t = 'bodacious'
#write Python code that prints out udacious
#without using any quote characters in
#your code.

#DO NOT USE IMPORT



print s[0:3] + t[4:]



