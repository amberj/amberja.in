#Write Python code that prints out the number of hours in 7 weeks.

#DO NOT USE IMPORT

print 7 * 7 * 24 
