#Define a procedure, greatest,
#that takes as input a list
#of positive numbers, and
#returns the greatest number
#in that list. If the input
#list is empty, the output
#should be 0.

#greatest([4,23,1]) => 23
#greatest([]) => 0

def greatest(n):
    if len(n) == 0:
        return 0
    max = n[0]
    for i in n:
        if max <= i:
            max = i
    return max


# print greatest([4,23,1])
#print greatest([])
