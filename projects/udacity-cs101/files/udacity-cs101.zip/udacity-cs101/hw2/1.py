# Define a procedure, udacify, that takes as 
# input a string, and returns a string that 
# is an uppercase 'U' followed by the input string.
# for example, when we enter

# print udacify('dacians')

# the output should be the string 'Udacians'

# Make sure your procedure has a return statement.

def udacify(s):
    return 'U' + s

#print udacify('dacians')







