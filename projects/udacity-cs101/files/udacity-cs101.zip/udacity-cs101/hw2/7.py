#2 GOLD STARS

#Define a procedure,
#print_multiplication_table,
#that takes as input a positive whole
#number, and prints out a multiplication,
#table showing all the whole number
#multiplications up to and including the
#input number. The order in which the
#equations are printed must match exactly.

#print_multiplication_table(2)
#1 * 1 = 1
#1 * 2 = 2
#2 * 1 = 2
#2 * 2 = 4

def print_multiplication_table(n):
    d = 1
    while d <=n:
        a = 1
        while a <=n:
            res = d * a
            print str(d) + ' * ' + str(a) + " = " +str(res)
            a = a + 1
        d = d + 1

#print_multiplication_table(4)
    
